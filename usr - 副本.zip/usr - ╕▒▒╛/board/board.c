/******************** (C) COPYRIGHT 2015 INCUBECN *****************************
* File Name          : board.c
* Author             : Tiko Zhong
* Date First Issued  : 6/15/2022
* Description        : 
*                      
********************************************************************************
* History:
* Jun20,2022: V0.1
*******************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include "board.h"
#include "main.h"
#include "gpioDecal.h"
#include "at24cxx.h"

/* import handle from main.c variables ----------------------------------------*/
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
const char ABOUT[] = {"aplental qt console ver1.0"};
const char COMMON_HELP[] = {
	"common help:"
	"\n %brd.help()"
	"\n %brd.about()"
	"\n %brd.restart()"
	"\n %brd.address()"
	"\n %brd.reg.read(addr)"
	"\n %brd.reg.write(addr,val)"
	"\n %brd.baud.set(bHost,bBus)"
	"\n %brd.baud.get()"
	"\n %brd.rom.format(val)"
	"\n %brd.rom.read_test(startAddr, endAddr)"
	"\n %brd.rom.write_test(startAddr, endAddr)"
	"\n"
};

char addrPre[4] = {0};	//addr precode
u8 boardAddr = 0;
static u8 addrTab[32] = {0};
static u8 boardMux = 0;

u8 initalDone = 0;
u8 baudHost = 4;		//BAUD[4]=115200
u8 baud485 = 4;
u16 ledTickTmr = 128;
u32 errorCode;			// = 0;
/**********************************************
*  PINs Define
**********************************************/
const PIN_T RUNNING = {BOOT0_LED1_GPIO_Port, BOOT0_LED1_Pin};

/**********************************************
*  static Devices
**********************************************/
#define RX_POOL_LEN	(MAX_CMD_LEN)
#define TX_POOL_LEN	(MAX_CMD_LEN)
#define	RX_BUF_LEN	(128)
// uart device
static u8 uartRxPool[RX_POOL_LEN] = {0};
static u8 uartRxBuf[2*RX_BUF_LEN] = {0};
static u8 uartTxPool[TX_POOL_LEN] = {0};
UartDev_t console;

// rs485 device
const PIN_T DE = {DE_GPIO_Port, DE_Pin};
const PIN_T DET = {DET_GPIO_Port, DET_Pin};
static u8 rs485RxPool[RX_POOL_LEN] = {0};
static u8 rs485RxBuf[2*RX_BUF_LEN] = {0};
static u8 rs485TxPool[TX_POOL_LEN] = {0};
static s8 rs485AfterSend_1(UART_HandleTypeDef *huart);
static s8 rs485BeforeSend_1(void);
Rs485Dev_t rs485;

// storage device
const PIN_T SCL = {SCL_GPIO_Port, SCL_Pin};
const PIN_T SDA = {SDA_GPIO_Port, SDA_Pin};
AT24CXX_Dev_T eeprom;
#define EEPROM_SIZE_USR			(1024*32-16*4-16*1)
#define EEPROM_SIZE_REG			(16*4)
#define EEPROM_SIZE_CFG			(16*1)
// define app eeprom base address
#define EEPROM_BASE_USER		(0)
#define EEPROM_BASE_REG			(EEPROM_BASE_USER + EEPROM_SIZE_USR)
#define EEPROM_BASE_CFG			(EEPROM_BASE_REG + EEPROM_SIZE_REG)
static s8 configWrite(void);	// system config write
static s8 configRead(void);		// system config read

//static u8 getAddr(void);
/* Private function prototypes -----------------------------------------------*/
// after GPIO initial, excute this function to enable
static void sayHello();

void boardPreInit(void){
	AT24CXX_Setup(&eeprom, SCL, SDA, AT24C256, 0);
	configRead();
}

void boardInit(void){
	u8 i;

	// attention, watch dog will bite you without fedding it in 32 mSeccond.
	HAL_GPIO_WritePin(RUNNING.GPIOx, RUNNING.GPIO_Pin, GPIO_PIN_SET);

	//read board addr
	setupUartDev(&console, &huart2, uartTxPool, RX_POOL_LEN, uartRxPool, RX_POOL_LEN, uartRxBuf, RX_BUF_LEN);

	memset(addrPre,0,4);
	strFormat(addrPre, 4, "%d.", boardAddr);
	print("%d.about(\"%s\")\r\n", boardAddr, ABOUT);

	printS("setup rs485...");
	setupRs485Dev(&rs485, &huart1, rs485TxPool, RX_POOL_LEN, rs485RxPool, RX_POOL_LEN, rs485RxBuf, RX_BUF_LEN, DE, DET,
		rs485BeforeSend_1,
		rs485AfterSend_1
	);
	printS("ok\r\n");

	console.StartRcv(&console.rsrc);
	rs485.rsrc.uartdev.StartRcv(&rs485.rsrc.uartdev.rsrc);
	// when it get ready to receive
	HAL_GPIO_WritePin(rs485.rsrc.DE.GPIOx, rs485.rsrc.DE.GPIO_Pin, GPIO_PIN_RESET);

	printS("initial complete, need help? Try bellow:");
	print("\n%d.help()", boardAddr);
	printS("\r\n");
	console.TxPolling(&console.rsrc);

	sayHello();
	initalDone = 1;
}

static void sayHello(){
	u8 i;
	for(i=0;i<10;i++){
		HAL_GPIO_TogglePin(RUNNING.GPIOx, RUNNING.GPIO_Pin);
		HAL_Delay(10); HAL_IWDG_Refresh(&hiwdg);
		HAL_Delay(10); HAL_IWDG_Refresh(&hiwdg);
	}
}

void printS(const char* STRING){
	console.Send(&console.rsrc, (const u8*)STRING, strlen(STRING));
}

void print(const char* FORMAT_ORG, ...){
	va_list ap;
	char buf[MAX_CMD_LEN] = {0};
	s16 bytes;
	//take string
	va_start(ap, FORMAT_ORG);
	bytes = vsnprintf(buf, MAX_CMD_LEN, FORMAT_ORG, ap);
	va_end(ap);
	//send out
	if(bytes>0)	console.Send(&console.rsrc, (u8*)buf, bytes);
}

void printS485(const char* STRING){
	rs485.Send(&rs485.rsrc, (const u8*)STRING, strlen(STRING));
}

void print485(const char* FORMAT_ORG, ...){
	va_list ap;
	char buf[MAX_CMD_LEN] = {0};
	s16 bytes;
	//take string
	va_start(ap, FORMAT_ORG);
	bytes = vsnprintf(buf, MAX_CMD_LEN, FORMAT_ORG, ap);
	va_end(ap);
	//send out
	if(bytes>0)	rs485.Send(&rs485.rsrc, (u8*)buf, bytes);
}

s8 ioWrite(u16 addr, const u8 *pDat, u16 nBytes){
	eeprom.Write(&eeprom.rsrc, EEPROM_BASE_USER + addr, pDat, nBytes);
	return 0;
}

s8 ioRead(u16 addr, u8 *pDat, u16 nBytes){
	eeprom.Read(&eeprom.rsrc, EEPROM_BASE_USER + addr, pDat, nBytes);
	return 0;
}

s8 ioReadReg(u16 addr, s32 *val){
	return(eeprom.Read(&eeprom.rsrc, EEPROM_BASE_REG + addr*4, (u8*)val, 4));
}

s8 ioWriteReg(u16 addr, s32 val){
	return(eeprom.Write(&eeprom.rsrc, EEPROM_BASE_REG + addr*4, (u8*)&val, 4));
}

static s8 configWrite(void){
	u8 buff[16]={0};
	u16 sum = 0,i;
	buff[0] = baudHost;
	buff[1] = baud485;
	buff[2] = boardAddr;
	buff[3] = boardAddr>>8;
	buff[4] = boardMux;
	for(i=0;i<14;i++){	sum += buff[i];	}
	buff[14] = sum;
	buff[15] = sum>>8;
	eeprom.Write(&eeprom.rsrc, EEPROM_SIZE_CFG, buff, 16);
	return 0;
}

static s8 configRead(void){
	u8 buff[16] = {0};
	u16 sum,checkcode,i;
	eeprom.Read(&eeprom.rsrc, EEPROM_SIZE_CFG, buff, 16);
	for(i=0,sum=0;i<14;i++){	sum += buff[i];	}
	checkcode = buff[15];	checkcode <<= 8;
	checkcode |= buff[14];

	if(sum == checkcode){
		baudHost = buff[0];
		baud485 = buff[1];
		if(baudHost >= 7)	 baudHost = 2;	// 2@115200
		if(baud485 >= 7)	 baud485 = 2;	// 2@115200
		boardAddr = buff[3];	boardAddr <<= 8;
		boardAddr |= buff[2];
		boardMux = buff[4];
	}
	else{
		baudHost = 2;	// 2@115200
		baud485 = 2;	// 2@115200
		boardAddr = 0;
		boardMux = 0;
	}

	return 0;
}

void printHelp(u8 brdAddr, void (*xprint)(const char* FORMAT_ORG, ...)){
	xprint("+ok@%d.help()\n%s", boardAddr, COMMON_HELP);
}

u8 brdCmd(const char* CMD, u8 brdAddr, void (*xprint)(const char* FORMAT_ORG, ...)){
	s32 i=0,j=0,k=0, ii;
	u8 buff[256] = {0};
	// common

	if(strncmp(CMD, "about", strlen("about")) == 0){
		xprint("+ok@%d.about(\"%s\")\r\n", brdAddr, ABOUT);
		sayHello();
		return 1;
	}
	else if(strncmp(CMD, "help", strlen("help")) == 0){
		printHelp(brdAddr, xprint);
		return 1;
	}
	else if(strncmp(CMD, "restart", strlen("restart")) == 0){
		HAL_NVIC_SystemReset();
		return 1;
	}

	else if(sscanf(CMD, "address %d", &i)==1){
		boardAddr = i;
		configWrite();
		memset(addrPre,0,4);
		strFormat(addrPre, 4, "%d.", boardAddr);
		xprint("+ok@%d.address(%d)\r\n", brdAddr, i);
		return 1;
	}

	else if(sscanf(CMD, "rom.format %d", &i)==1){
		memset(buff,i,256);
		eeprom.Write(&eeprom.rsrc, 0,buff,256);
		xprint("+ok@%d.rom.format(%d)\r\n", brdAddr, i);
		return 1;
	}
	else if(sscanf(CMD, "rom.write_test %d %d", &i, &j)==2){
		buff[0] = 0;
		for(ii=i;ii<=j;ii++){
			eeprom.Write(&eeprom.rsrc, ii, buff, 1);
			buff[0] ++;
			HAL_IWDG_Refresh(&hiwdg);
			HAL_Delay(10);
		}
		xprint("+ok@%d.rom.write_test(%d,%d)\r\n", brdAddr, i, j);
		return 1;
	}

	else if(sscanf(CMD, "rom.read_test %d %d", &i, &j)==2){
		k = 0;
		for(ii=i;ii<=j;ii++){
			eeprom.Read(&eeprom.rsrc, ii, buff, 1);
			k++;
			HAL_IWDG_Refresh(&hiwdg);
			if(k%16==0){
				xprint("%02x\n", buff[0]);
				k = 0;
			}
			else xprint("%02x ", buff[0]);
			console.TxPolling(&console.rsrc);
		}
		xprint("+ok@%d.rom.read_test(%d,%d)\r\n", brdAddr, i, j);
		return 1;
	}

	else if(sscanf(CMD, "reg.write %d %d ", &i, &j)==2){
		if(i>=EEPROM_SIZE_REG/4)	{
			xprint("+err@%d.reg.write(\"0..%d\")\r\n", brdAddr, EEPROM_SIZE_REG/4-1);
			return 1;
		}
		if(ioWriteReg(i&0xffff,j) == 0)	xprint("+ok@%d.reg.write(%d,%d)\r\n", brdAddr, i, j);
		else xprint("+err@%d.reg.write(%d,%d)\r\n", brdAddr, i, j);
		return 1;
	}

	else if(sscanf(CMD, "reg.read 0x%x ", &i)==1){
		if(i>=EEPROM_SIZE_REG/4){
			xprint("+err@%d.reg.read(\"0..%d\")\r\n", brdAddr, EEPROM_SIZE_REG/4-1);
			return 1;
		}
		j = 0;
		ioReadReg(i&0xffff, &j);
		xprint("+ok@%d.reg.read(0x%02x, 0x%02x)\r\n", brdAddr, i, j);
		return 1;
	}


	else if(sscanf(CMD, "reg.read %d ", &i)==1){
		if(i>=EEPROM_SIZE_REG/4){
			xprint("+err@%d.reg.read(\"0..%d\")\r\n", brdAddr, EEPROM_SIZE_REG/4-1);
			return 1;
		}
		j = 0;
		ioReadReg(i&0xffff, &j);
		xprint("+ok@%d.reg.read(%d,%d)\r\n", brdAddr, i, j);
		return 1;
	}
	// baud config command
	else if(sscanf(CMD, "baud.set %d %d", &i,&j)==2){
		for(k=0;k<7;k++){
			baudHost = k;
			if(i==BAUD[baudHost])	break;
		}
		for(k=0;k<7;k++){
			baud485 = k;
			if(j==BAUD[baud485])	break;
		}
		configWrite();
		xprint("+ok@%d.baud.set(%d,%d)\r\n", brdAddr, BAUD[baudHost], BAUD[baud485]);
		return 1;
	}
	else if(strncmp(CMD, "baud.get ", strlen("baud.get "))==0){
		configRead();
		xprint("+ok@%d.baud.get(%d,%d)\r\n", brdAddr, BAUD[baudHost], BAUD[baud485]);
		return 1;
	}

	// baud config command
	else if(sscanf(CMD, "mux.set %d", &i)==1){
		boardMux = i;
		configWrite();
		xprint("+ok@%d.mux.set(%d)\r\n", brdAddr, boardMux);
		return 1;
	}
	else if(strncmp(CMD, "mux.get", strlen("mux.get"))==0){
		configRead();
		xprint("+ok@%d.mux.get(%d)\r\n", brdAddr, boardMux);
		return 1;
	}

	return 0;
}

static s8 rs485BeforeSend_1(void){
	if(initalDone == 0)	return 0;
	if(HAL_GPIO_ReadPin(rs485.rsrc.DET.GPIOx, rs485.rsrc.DET.GPIO_Pin)==GPIO_PIN_SET){
		return -1;
	}
	HAL_GPIO_WritePin(rs485.rsrc.DE.GPIOx, rs485.rsrc.DE.GPIO_Pin, GPIO_PIN_SET);
	while(1){
		if(HAL_GPIO_ReadPin(rs485.rsrc.DET.GPIOx, rs485.rsrc.DET.GPIO_Pin)==GPIO_PIN_SET){
			break;
		}
	}
	return 0;
}

static s8 rs485AfterSend_1(UART_HandleTypeDef *huart){
	if(huart->Instance == rs485.rsrc.uartdev.rsrc.huart->Instance){
		HAL_GPIO_WritePin(rs485.rsrc.DE.GPIOx, rs485.rsrc.DE.GPIO_Pin, GPIO_PIN_RESET);
		rs485.rsrc.uartdev.rsrc.flag |= BIT(0);
	}
	return 0;
}

/**
  * @brief  Conversion complete callback in non blocking mode
  * @param  AdcHandle : ADC handle
  * @note   This example shows a simple way to report end of conversion
  *         and get conversion result. You can add your own implementation.
  * @retval None
  */
// void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *AdcHandle){}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart){
	if(initalDone==0)	return;
	rs485.rsrc.uartdev.rsrc.afterSend(huart);
	if(huart->Instance == console.rsrc.huart->Instance){
		console.rsrc.flag |= BIT(0);
	}
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){

}

void HAL_GPIO_EXTI_Falling_Callback(uint16_t GPIO_Pin){
	if(initalDone == 0)	return;
}

void HAL_GPIO_EXTI_Rising_Callback(uint16_t GPIO_Pin){
	if(initalDone == 0)	return;
}


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
