# xUartDev
uart device
