/******************** (C) COPYRIGHT 2022 INCUBECN *****************************
* File Name          : aplental_qt.c
* Author             : Tiko Zhong
* Date First Issued  : 09/21,2022
* Description        : This file provides a set of functions needed to manage the
*                      stepper ramp generator
*******************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include "aplental_qt.h"

/* Private typedef -----------------------------------------------------------*/
const char SSS[] = {
	"$send 50 1.input.read 0 1\r\n"
	"$delay 200\r\n"
};

// disconnect. final target: release DUT, pogo disconnect, cap-carrier back to standby position
const reqNRes_t SCRIPT_DISCONNECT[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// cap stepper go home
	{"2.m0.homing(64000)",			100,	"+ok@2.m0.homing()"},
	// button press probe stepper go home
	{"2.m1.homing(64000)",			100,	"+ok@2.m1.homing()"},
	// check cap pan steppers is home position before carrie move
	{"2.m0.pos()",					5000,	"+ok@2.m0.pos(0)"},
	// cap pen carrier goes to standby position
	{"1.output.writepin(2,1,3,0)",	100,	"+ok@1.output.writepin"},
	{"1.input.readpin(11,1)",		3000,	"+ok@1.input.readpin(11,1,1,0)"},
	// POGO disconnect
	{"1.output.writepin(4,1,5,0)",	50,		"+ok@1.output.writepin"},
	{"1.input.readpin(12,4)",		3000,	"+ok@1.input.readpin(12,1,4,0)"},
	// before press carrier goes up, 下压之前的干涉查询
	{"1.input.readpin(11,1)",		3000,	"+ok@1.input.readpin(11,1,1,0)"},
	// press carrier goes up
	{"1.output.writepin(6,1,7,0)",	50,		"+ok@1.output.writepin"},
	{"1.input.readpin(13,5)",		3000,	"+ok@1.input.readpin(13,1,5,0)"},
	// button press probe go to standby position
	{"2.m1.pos()",					9500,	"+ok@2.m1.pos(0)"},
	{"1.output.writepin(0,1,1,0)",	50,		"+ok@1.output.writepin"},
	{"1.input.readpin(10,2)",		3000,	"+ok@1.input.readpin(10,1,2,0)"},
	{"$$.jmp abc",					0,		"+ok@1.input.readpin(10,1,2,0)"	},
	{APP_END,						0,		APP_ANY	}
};

// connect. final target: press down, pogo connect, ca carrier go to work position
const reqNRes_t SCRIPT_CONNECT[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// cap stepper go home
	{"2.m0.homing(64000)",			100,	"+ok@2.m0.homing()"},
	// button press probe stepper go home
	{"2.m1.homing(64000)",			100,	"+ok@2.m1.homing"},
	// 下压之前的干涉查询
	{"1.input.readpin(11,1)",		3000,	"+ok@1.input.readpin(11,1,1,0)"},
	// 执行下压
	{"1.output.writepin(6,0,7,1)",	50,		"+ok@1.output.writepin"},
	{"1.input.readpin(13,5)",		3000,	"+ok@1.input.readpin(13,0,5,1)"},
	// POGO connect
	{"1.output.writepin(4,0,5,1)",	50,		"+ok@1.output.writepin"},
	{"1.input.readpin(12,4)",		3000,	"+ok@1.input.readpin(12,0,4,1)"},
	{APP_END,						0,		APP_ANY	}
};

const reqNRes_t button_push[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// button probe carrier goes to work postion
	{"2.m1.pos()",					9500,	"+ok@2.m1.pos(0)"},
	{"1.output.writepin(0,0,1,1)",	50,		"+ok@1.output.writepin"},
	{"1.input.readpin(10,2)",		3000,	"+ok@1.input.readpin(10,0,2,1)"},
	// move stepper
	{"2.m1.moveto(26800,64700)",	100,	"+ok@2.m1.moveto(26800,64700)"},
	{"2.m1.pos()",					9000,	"+ok@2.m1.pos(26800)"},
	//{"$$.delay 500",				0,		"$$any"},
	{"2.m1.homing(64000)",			100,	"+ok@2.m1.homing"},
	{"2.m1.pos()",					5000,	"+ok@2.m1.pos(0)"},
	{APP_END,						0,		APP_ANY	}
};

const reqNRes_t button_home[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// cap pen carrier goes to standby position
	{"2.m1.homing(64700)",			100,	"+ok@2.m1.homing"},
	{"2.m1.pos()",					100,	"+ok@2.m1.pos(0)"},
	{"1.output.writepin(0,1,1,0)",	100,	"+ok@1.output.writepin"},
	{"1.input.readpin(10,2)",		3000,	"+ok@1.input.readpin(10,1,2,0)"},
	{APP_END,						0,		APP_ANY	}
};

const reqNRes_t screen_touch[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// cap stepper go home
	{"2.m0.homing(64700)",			100,	"+ok@2.m0.homing()"},
	{"2.m0.pos()",					5000,	"+ok@2.m0.pos(0)"},
	// cap pen goto workd pos
	{"1.output.writepin(2,0,3,1)",	50,		"+ok@1.output.writepin"},
	{"1.input.readpin(11,1)",		3000,	"+ok@1.input.readpin(11,0,1,1)"},
	// move stepper
	{"2.m0.moveto(38000,64700)",	100,	"+ok@2.m0.moveto(38000,64700)"},
	{"2.m0.pos()",					5000,	"+ok@2.m0.pos(38000)"},
	//{"$$.delay 500 ",				0,		"$$any"},
	{"2.m0.homing(64700)",			100,	"+ok@2.m0.homing"},
	{"2.m0.pos()",					5000,	"+ok@2.m0.pos(0)"},
	{APP_END,						0,		APP_ANY	}
};

const reqNRes_t screen_home[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// cap pen carrier goes to standby position
	{"2.m0.homing(64700)",			100,	"+ok@2.m0.homing"},
	{"2.m0.pos()",					3000,	"+ok@2.m0.pos(0)"},
	{"1.output.writepin(2,1,3,0)",	100,	"+ok@1.output.writepin"},
	{"1.input.readpin(11,1)",		3000,	"+ok@1.input.readpin(11,1,1,0)"},
	{APP_END,						0,		APP_ANY	}
};

// 触摸笔carrier到工作位
// 1.output.writepin 2 0 3 1
const reqNRes_t safty_1_output_writepin_2_0_3_1[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	{"2.m0.pos()",					100,	"+ok@2.m0.pos(0)"},
	// cap pen goto workd pos
	{"1.output.writepin(2,0,3,1)",	100,	"+ok@1.output.writepin"},
	{APP_END,						0,		APP_ANY	}
};

// 触摸笔carrier到待命位
// 1.output.writepin 2 1 3 0
const reqNRes_t safty_1_output_writepin_2_1_3_0[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// cap stepper go home
	{"2.m0.pos()",					100,	"+ok@2.m0.pos(0)"},
	// cap pen goto workd pos
	{"1.output.writepin(2,1,3,0)",	100,	"+ok@1.output.writepin"},
	{APP_END,						0,		APP_ANY	}
};

// 天花到待命位
// 1.output.writepin 6 1 7 0
const reqNRes_t safty_1_output_writepin_6_1_7_0[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// cap stepper go home
	{"1.input.readpin(11,1)",		100,	"+ok@1.input.readpin(11,1,1,0)"},
	// cap pen goto workd pos
	{"1.output.writepin(6,1,7,0)",	100,	"+ok@1.output.writepin"},
	{APP_END,						0,		APP_ANY	}
};

// 天花到工作位
// 1.output.writepin 6 0 7 1
const reqNRes_t safty_1_output_writepin_6_0_7_1[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// cap stepper go home
	{"1.input.readpin(11,1)",		100,	"+ok@1.input.readpin(11,1,1,0)"},
	// cap pen goto workd pos
	{"1.output.writepin(6,0,7,1)",	100,	"+ok@1.output.writepin"},
	{APP_END,						0,		APP_ANY	}
};

// 按压头carrier到待命位
// 1.output.writepin 0 1 1 0
const reqNRes_t safty_1_output_writepin_0_1_1_0[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// before probe carrier move
	{"2.m1.pos()",					100,	"+ok@2.m1.pos(0)"},
	// cap pen goto workd pos
	{"1.output.writepin(0,1,1,0)",	100,	"+ok@1.output.writepin"},
	{APP_END,						0,		APP_ANY	}
};

// 按压头carrier到工作位
// 1.output.writepin 0 0 1 1
const reqNRes_t safty_1_output_writepin_0_0_1_1[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// before probe carrier move
	{"2.m1.pos()",					100,	"+ok@2.m1.pos(0)"},
	// cap pen goto workd pos
	{"1.output.writepin(0,0,1,1)",	100,	"+ok@1.output.writepin"},
	{APP_END,						0,		APP_ANY	}
};

// pogo carrier到待命位
// 1.output.writepin 4 1 5 0
const reqNRes_t safty_1_output_writepin_4_1_5_0[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// before touch pen carrier move
	{"2.m0.pos()",					100,	"+ok@2.m0.pos(0)"},
	// cap pen goto workd pos
	{"1.output.writepin(4,1,5,0)",	100,	"+ok@1.output.writepin"},
	{APP_END,						0,		APP_ANY	}
};

// pogo carrier到工作位
// 1.output.writepin 0 0 1 1
const reqNRes_t safty_1_output_writepin_4_0_5_1[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// before touch pen carrier move
	{"2.m0.pos()",					100,	"+ok@2.m0.pos(0)"},
	// cap pen goto workd pos
	{"1.output.writepin(4,0,5,1)",	100,	"+ok@1.output.writepin"},
	{APP_END,						0,		APP_ANY	}
};

// 按压头电机到工作位
// 2.m1.moveto(26800, 64500)
const reqNRes_t safty_2_m1_moveto[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	// probe must be in work position
	{"1.input.readpin(10,2)",		100,	"+ok@1.input.readpin(10,0,2,1)"},
	// cap pen goto workd pos
	{"2.m1.moveto(26800,64500)",	100,	"+ok@2.m1.moveto"},
	{APP_END,						0,		APP_ANY	}
};

// touch sensor电机到工作位
// 2.m1.moveto(26800, 64500)
const reqNRes_t safty_2_m0_moveto[] = {
	{APP_START,						0,		APP_ANY	},
	{"1.input.readpin(9)",			100,	"+ok@1.input.readpin(9,1)"},
	{"1.input.readpin(12,4)",		100,	"+ok@1.input.readpin(12,1,4,0)"},
	// cap pen goto workd pos
	{"2.m0.moveto(38000,64500)",	100,	"+ok@2.m0.moveto"},
	{APP_END,						0,		APP_ANY	}
};

const scriptBind_t script[SCRIPT_LEN] = {
	{"disconnect", 	SCRIPT_DISCONNECT},
	{"connect", 	SCRIPT_CONNECT},
	{"button.push", 	button_push},
	{"button.home", 	button_home},
	{"screen.touch", 	screen_touch},
	{"screen.home", 	screen_home},
	// 触摸笔carrier到工作位
	{"1.output.writepin 2 0 3 1", 	safty_1_output_writepin_2_0_3_1},
	{"1.output.writepin(2,0,3,1)", 	safty_1_output_writepin_2_0_3_1},
	// 触摸笔carrier到待命位
	{"1.output.writepin 2 1 3 0", 	safty_1_output_writepin_2_1_3_0},
	{"1.output.writepin(2,1,3,0)", 	safty_1_output_writepin_2_1_3_0},
	// 天花到待命位
	{"1.output.writepin 6 1 7 0", 	safty_1_output_writepin_6_1_7_0},
	{"1.output.writepin(6,1,7,0)", 	safty_1_output_writepin_6_1_7_0},
	// 天花到工作位
	{"1.output.writepin 6 0 7 1", 	safty_1_output_writepin_6_0_7_1},
	{"1.output.writepin(6,0,7,1)", 	safty_1_output_writepin_6_0_7_1},
	// 按压头carrier到待命位
	{"1.output.writepin 0 1 1 0", 	safty_1_output_writepin_0_1_1_0},
	{"1.output.writepin(0,1,1,0)", 	safty_1_output_writepin_0_1_1_0},
	// 按压头carrier到工作位
	{"1.output.writepin 0 0 1 1", 	safty_1_output_writepin_0_0_1_1},
	{"1.output.writepin(0,0,1,1)", 	safty_1_output_writepin_0_0_1_1},
	// 按压头电机到工作位
	{"2.m1.moveto", 	safty_2_m1_moveto},
	// touch sensor电机到工作位
	{"2.m0.moveto", 	safty_2_m0_moveto},
	// pogo carrier到待命位
	{"1.output.writepin 4 1 5 0", 	safty_1_output_writepin_4_1_5_0},
	{"1.output.writepin(4,1,5,0)", 	safty_1_output_writepin_4_1_5_0},
	// pogo carrier到工作位
	{"1.output.writepin 4 0 5 1", 	safty_1_output_writepin_4_0_5_1},
	{"1.output.writepin(4,0,5,1)", 	safty_1_output_writepin_4_0_5_1},
};

/******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE****/
