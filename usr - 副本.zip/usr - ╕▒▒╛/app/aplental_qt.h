/******************** (C) COPYRIGHT 2022 INCUBECN *****************************
* File Name          : aplental_qt.h
* Author             : Tiko Zhong
* Date First Issued  : 09/21,2022
* Description        : This file provides a set of functions needed to manage the
*                      stepper ramp generator
********************************************************************************
* History:e
* 09/21,2022: V0.0
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _APLENTAL_QT_H
#define _APLENTAL_QT_H

#include "misc.h"
#include "script_player.h"

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
#define SCRIPT_LEN	24
extern const scriptBind_t script[SCRIPT_LEN];

#endif /* _APLENTAL_QT_H */

/******************* (C) COPYRIGHT 2015 INCUBECN *****END OF FILE****/
